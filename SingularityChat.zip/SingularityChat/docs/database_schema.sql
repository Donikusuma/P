-- ============================================================
-- SUPABASE CHAT DATABASE SCHEMA — PRODUCTION READY 2026
-- PostgreSQL 15+ | Row Level Security Enabled | Zero Trust
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_audit;

-- ============================================================
-- TABLE: profiles (extends auth.users)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    username TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    avatar_url TEXT,
    phone TEXT,
    is_anonymous BOOLEAN DEFAULT TRUE,
    status TEXT DEFAULT 'online' CHECK (status IN ('online', 'away', 'offline')),
    last_seen_at TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT username_length CHECK (char_length(username) >= 3 AND char_length(username) <= 30),
    CONSTRAINT display_name_length CHECK (char_length(display_name) >= 1 AND char_length(display_name) <= 50)
);

COMMENT ON TABLE public.profiles IS 'User profiles extending Supabase Auth. Anonymous users allowed.';

-- ============================================================
-- TABLE: rooms (chat rooms / groups)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.rooms (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    avatar_url TEXT,
    created_by UUID NOT NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
    is_public BOOLEAN DEFAULT TRUE NOT NULL,  -- anyone can join, no barriers
    is_direct_message BOOLEAN DEFAULT FALSE NOT NULL,
    max_members INTEGER DEFAULT 1000 CHECK (max_members > 0 AND max_members <= 5000),
    member_count INTEGER DEFAULT 0,
    message_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT room_name_length CHECK (char_length(name) >= 1 AND char_length(name) <= 100)
);

COMMENT ON TABLE public.rooms IS 'Chat rooms. Public rooms allow zero-barrier entry.';

-- ============================================================
-- TABLE: room_members (junction)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.room_members (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role TEXT DEFAULT 'member' CHECK (role IN ('owner', 'admin', 'member')),
    joined_at TIMESTAMPTZ DEFAULT NOW(),
    last_read_message_id UUID,
    is_muted BOOLEAN DEFAULT FALSE,
    UNIQUE(room_id, user_id)
);

COMMENT ON TABLE public.room_members IS 'Many-to-many relationship users <-> rooms.';

-- ============================================================
-- TABLE: messages
-- ============================================================
CREATE TABLE IF NOT EXISTS public.messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE SET NULL,
    content TEXT NOT NULL,
    content_type TEXT DEFAULT 'text' CHECK (content_type IN ('text', 'image', 'file', 'system')),
    reply_to_message_id UUID REFERENCES public.messages(id) ON DELETE SET NULL,
    metadata JSONB DEFAULT '{}',
    is_edited BOOLEAN DEFAULT FALSE,
    edited_at TIMESTAMPTZ,
    idempotency_key TEXT UNIQUE,  -- prevents duplicate sends
    created_at TIMESTAMPTZ DEFAULT NOW(),
    CONSTRAINT content_length CHECK (char_length(content) <= 4096)
);

COMMENT ON TABLE public.messages IS 'Chat messages with idempotency protection.';

-- ============================================================
-- TABLE: message_reads (read receipts)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.message_reads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id UUID NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    read_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(message_id, user_id)
);

-- ============================================================
-- TABLE: message_reactions
-- ============================================================
CREATE TABLE IF NOT EXISTS public.message_reactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id UUID NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    emoji TEXT NOT NULL CHECK (char_length(emoji) BETWEEN 1 AND 10),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(message_id, user_id, emoji)
);

-- ============================================================
-- TABLE: attachments (media files)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.attachments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    message_id UUID REFERENCES public.messages(id) ON DELETE SET NULL,
    file_name TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_size INTEGER NOT NULL CHECK (file_size > 0 AND file_size <= 52428800), -- 50MB max
    storage_path TEXT NOT NULL,
    public_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABLE: typing_indicators (ephemeral)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.typing_indicators (
    room_id UUID NOT NULL REFERENCES public.rooms(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    started_at TIMESTAMPTZ DEFAULT NOW(),
    PRIMARY KEY (room_id, user_id)
);

-- Auto-cleanup typing indicators older than 30 seconds
CREATE OR REPLACE FUNCTION cleanup_old_typing()
RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM public.typing_indicators WHERE started_at < NOW() - INTERVAL '30 seconds';
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER typing_cleanup_trigger
    AFTER INSERT ON public.typing_indicators
    EXECUTE FUNCTION cleanup_old_typing();

-- ============================================================
-- TABLE: audit_log (immutable)
-- ============================================================
CREATE TABLE IF NOT EXISTS public.audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name TEXT NOT NULL,
    record_id UUID NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
    old_data JSONB,
    new_data JSONB,
    performed_by UUID,
    performed_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES (Performance)
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_messages_room_created 
    ON public.messages(room_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_sender 
    ON public.messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_room_members_room 
    ON public.room_members(room_id);
CREATE INDEX IF NOT EXISTS idx_room_members_user 
    ON public.room_members(user_id);
CREATE INDEX IF NOT EXISTS idx_message_reads_message 
    ON public.message_reads(message_id);
CREATE INDEX IF NOT EXISTS idx_rooms_public 
    ON public.rooms(is_public) WHERE is_public = TRUE;
CREATE INDEX IF NOT EXISTS idx_audit_performed_at 
    ON public.audit_log(performed_at DESC);

-- ============================================================
-- FUNCTIONS: Updated counters atomically
-- ============================================================
CREATE OR REPLACE FUNCTION increment_room_member_count()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE public.rooms SET member_count = member_count + 1, updated_at = NOW() WHERE id = NEW.room_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION decrement_room_member_count()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE public.rooms SET member_count = member_count - 1, updated_at = NOW() WHERE id = OLD.room_id;
    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION increment_room_message_count()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE public.rooms SET message_count = message_count + 1, updated_at = NOW() WHERE id = NEW.room_id;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_room_members_insert
    AFTER INSERT ON public.room_members
    FOR EACH ROW EXECUTE FUNCTION increment_room_member_count();

CREATE TRIGGER trg_room_members_delete
    AFTER DELETE ON public.room_members
    FOR EACH ROW EXECUTE FUNCTION decrement_room_member_count();

CREATE TRIGGER trg_messages_insert
    AFTER INSERT ON public.messages
    FOR EACH ROW EXECUTE FUNCTION increment_room_message_count();

-- ============================================================
-- ROW LEVEL SECURITY POLICIES (Zero Trust)
-- ============================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.rooms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.room_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_reads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attachments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.typing_indicators ENABLE ROW LEVEL SECURITY;

-- PROFILES: Users can read all profiles (public info), update only own
CREATE POLICY "Profiles are viewable by everyone"
    ON public.profiles FOR SELECT USING (TRUE);

CREATE POLICY "Users can update own profile"
    ON public.profiles FOR UPDATE USING (auth.uid() = id);

-- ROOMS: Public rooms viewable by all. Private rooms only visible to members.
-- Anyone can create room (zero barrier).
CREATE POLICY "Public rooms viewable by all"
    ON public.rooms FOR SELECT USING (is_public = TRUE);

CREATE POLICY "Private rooms viewable by members"
    ON public.rooms FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.room_members rm 
            WHERE rm.room_id = rooms.id AND rm.user_id = auth.uid()
        )
    );

CREATE POLICY "Authenticated users can create rooms"
    ON public.rooms FOR INSERT WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Owners can update own rooms"
    ON public.rooms FOR UPDATE USING (auth.uid() = created_by);

-- ROOM_MEMBERS: Members can view memberships for rooms they belong to.
-- Anyone can join public room (zero barrier). Self-leave allowed.
CREATE POLICY "Members viewable by room participants"
    ON public.room_members FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.room_members rm 
            WHERE rm.room_id = room_members.room_id AND rm.user_id = auth.uid()
        )
    );

CREATE POLICY "Anyone can join public room"
    ON public.room_members FOR INSERT WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.rooms r 
            WHERE r.id = room_members.room_id AND r.is_public = TRUE
        ) AND user_id = auth.uid()
    );

CREATE POLICY "Users can leave room"
    ON public.room_members FOR DELETE USING (user_id = auth.uid());

-- MESSAGES: Viewable by room members only. Insert by room members only.
CREATE POLICY "Messages viewable by room members"
    ON public.messages FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.room_members rm 
            WHERE rm.room_id = messages.room_id AND rm.user_id = auth.uid()
        )
    );

CREATE POLICY "Room members can send messages"
    ON public.messages FOR INSERT WITH CHECK (
        sender_id = auth.uid() AND
        EXISTS (
            SELECT 1 FROM public.room_members rm 
            WHERE rm.room_id = messages.room_id AND rm.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can edit own messages"
    ON public.messages FOR UPDATE USING (sender_id = auth.uid());

-- MESSAGE_READS: Insert own reads. View reads for messages in joined rooms.
CREATE POLICY "Users can insert own read receipts"
    ON public.message_reads FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Read receipts viewable by room members"
    ON public.message_reads FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.messages m
            JOIN public.room_members rm ON m.room_id = rm.room_id
            WHERE m.id = message_reads.message_id AND rm.user_id = auth.uid()
        )
    );

-- MESSAGE_REACTIONS: Standard CRUD own, view by room members
CREATE POLICY "Reactions viewable by room members"
    ON public.message_reactions FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.messages m
            JOIN public.room_members rm ON m.room_id = rm.room_id
            WHERE m.id = message_reactions.message_id AND rm.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can add/remove own reactions"
    ON public.message_reactions FOR ALL USING (user_id = auth.uid());

-- ATTACHMENTS: Viewable by room members
CREATE POLICY "Attachments viewable by room members"
    ON public.attachments FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.messages m
            JOIN public.room_members rm ON m.room_id = rm.room_id
            WHERE m.id = attachments.message_id AND rm.user_id = auth.uid()
        )
    );

-- TYPING_INDICATORS: Viewable by room members, insert own only
CREATE POLICY "Typing viewable by room members"
    ON public.typing_indicators FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.room_members rm 
            WHERE rm.room_id = typing_indicators.room_id AND rm.user_id = auth.uid()
        )
    );

CREATE POLICY "Users can insert own typing status"
    ON public.typing_indicators FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can delete own typing status"
    ON public.typing_indicators FOR DELETE USING (user_id = auth.uid());

-- ============================================================
-- REALTIME PUBLICATIONS (enable for live subscriptions)
-- ============================================================
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.room_members;
ALTER PUBLICATION supabase_realtime ADD TABLE public.typing_indicators;
ALTER PUBLICATION supabase_realtime ADD TABLE public.message_reactions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
