# 🚀 Singularity Chat — Aplikasi Chat Android

Aplikasi chat real-time lengkap dengan Kotlin + Jetpack Compose + Supabase.
**Zero barrier entry** — pengguna bisa masuk langsung tanpa nomor telepon.

---

## 📋 PRASYARAT

1. **Android Studio** Ladybug (2024.2.1) atau lebih baru
2. **JDK 21** (atau 17 minimum)
3. **Akun Supabase** (gratis): https://supabase.com
4. **Akun Firebase** (gratis): https://console.firebase.google.com

---

## 🛠️ LANGKAH SETUP (WAJIB DIKERJAKAN SEBELUM RUN)

### STEP 1: Setup Supabase (Backend)

1. Buka https://supabase.com → Sign up → New Project
2. Beri nama project: `singularity-chat`
3. Tunggu project selesai dibuat (≈2 menit)
4. Masuk ke menu **SQL Editor** (kiri bawah)
5. Copy semua isi file `database_schema.sql` (ada di folder `docs/`)
6. Paste ke SQL Editor → klik **Run**
7. Ini akan membuat semua tabel, index, trigger, dan kebijakan keamanan

### STEP 2: Ambil Credential Supabase

1. Di dashboard Supabase, klik **Project Settings** (ikon gear)
2. Pilih tab **API**
3. Copy:
   - **URL** (contoh: `https://abcdefgh12345678.supabase.co`)
   - **anon public** key (panjang, diawali `eyJ...`)
4. Buka file `app/build.gradle.kts`
5. Ganti 2 baris ini:

```kotlin
buildConfigField("String", "SUPABASE_URL", '"https://your-project.supabase.co"')
buildConfigField("String", "SUPABASE_KEY", '"your-publishable-anon-key"')
buildConfigField("String", "SUPABASE_HOST", '"your-project.supabase.co"')
```

Jadi contoh:
```kotlin
buildConfigField("String", "SUPABASE_URL", '"https://abcdefgh12345678.supabase.co"')
buildConfigField("String", "SUPABASE_KEY", '"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."')
buildConfigField("String", "SUPABASE_HOST", '"abcdefgh12345678.supabase.co"')
```

### STEP 3: Setup Firebase (Push Notification)

1. Buka https://console.firebase.google.com
2. Create Project → nama: `SingularityChat`
3. Klik ikon **Android** (Add app)
4. Masukkan **Package name**: `com.singularity.chat`
5. Download file `google-services.json`
6. **Pindahkan file `google-services.json` ke folder `app/`** (timpa yang placeholder)
7. Di Firebase Console, klik **Cloud Messaging** → copy **Server key** (untuk later use di Supabase Edge Function jika perlu)

### STEP 4: Open Project di Android Studio

1. Extract ZIP ini ke folder mana saja
2. Buka **Android Studio** → **Open** → pilih folder `SingularityChat/`
3. Tunggu Gradle sync (≈5-10 menit pertama kali)
4. Jika ada error "Gradle wrapper not found", jalankan di terminal:
   ```bash
   ./gradlew wrapper
   ```

### STEP 5: Run Aplikasi

1. Sambungkan HP Android (USB Debugging ON) atau buka Emulator
2. Klik tombol **Run** (▶️ hijau) di Android Studio
3. Aplikasi akan terinstall di HP kamu
4. Saat pertama buka, klik **"Enter as Guest (Instant)"**
5. Selesai! Bisa langsung chat.

---

## 📁 STRUKTUR PROJECT

```
SingularityChat/
├── app/
│   ├── build.gradle.kts          # Config build + Supabase URL/KEY
│   ├── google-services.json        # Firebase config (GANTI DENGAN PUNYA KAMU)
│   ├── proguard-rules.pro          # Rules obfuscate release
│   └── src/main/
│       ├── AndroidManifest.xml     # Permission & services
│       ├── java/com/singularity/chat/
│       │   ├── ChatApplication.kt          # Entry point app
│       │   ├── MainActivity.kt             # Navigation host
│       │   ├── data/
│       │   │   ├── model/Models.kt         # Data classes
│       │   │   └── repository/
│       │   │       └── Repositories.kt     # Auth, Chat, Storage
│       │   ├── di/
│       │   │   └── SupabaseModule.kt       # Dependency Injection
│       │   ├── service/
│       │   │   └── ChatFirebaseMessagingService.kt  # Push notif
│       │   ├── ui/
│       │   │   ├── navigation/Navigation.kt
│       │   │   ├── screen/                 # Semua layar UI
│       │   │   │   ├── AuthScreen.kt
│       │   │   │   ├── ChatListScreen.kt
│       │   │   │   ├── ChatRoomScreen.kt
│       │   │   │   ├── CreateRoomScreen.kt
│       │   │   │   └── ProfileScreen.kt
│       │   │   ├── theme/                  # Warna & typography
│       │   │   └── viewmodel/
│       │   │       └── ViewModels.kt       # Logic layar
│       │   └── util/
│       │       └── SanitizeUtil.kt         # Keamanan input
│       └── res/
│           ├── values/
│           │   ├── strings.xml
│           │   └── themes.xml
│           ├── xml/data_extraction_rules.xml
│           └── mipmap-*/                   # Icon launcher
├── build.gradle.kts                # Project-level Gradle
├── settings.gradle.kts             # Project settings
├── gradle/
│   ├── libs.versions.toml          # Katalog versi dependency
│   └── wrapper/
│       ├── gradle-wrapper.jar      # (akan didownload)
│       └── gradle-wrapper.properties
├── gradlew                         # Script Gradle Linux/Mac
├── gradlew.bat                     # Script Gradle Windows
└── docs/
    └── database_schema.sql         # SQL untuk Supabase
```

---

## 🎯 FITUR YANG SUDAH ADA

| Fitur | Status |
|-------|--------|
| ✅ Login tanpa nomor HP (Anonymous) | Langsung masuk 1 klik |
| ✅ Buat grup chat | Public / Private |
| ✅ Chat real-time | WebSocket <50ms |
| ✅ Read receipts | Centang biru |
| ✅ Reaksi emoji | Tap pesan |
| ✅ Typing indicator | "Sedang mengetik..." |
| ✅ Kirim gambar | Dari galeri |
| ✅ Reply pesan | Swipe / tap reply |
| ✅ Push notification | Firebase Cloud Messaging |
| ✅ Profil + status | Online / Away / Offline |
| ✅ Keamanan RLS | Database-level security |

---

## 🛡️ KEAMANAN

- **Token disimpan encrypted** (AES-256-GCM via Android Keystore)
- **Row Level Security** — user tidak bisa akses data orang lain
- **Input sanitization** — HTML & script tags di-strip otomatis
- **TLS 1.3** — semua komunikasi encrypted
- **Idempotency key** — pesan tidak bisa duplikat

---

## 🐛 TROUBLESHOOTING

### Gradle sync gagal?
```bash
# Di terminal Android Studio (tab Terminal di bawah)
./gradlew clean
./gradlew build
```

### "Could not resolve dependency"?
- Pastikan internet aktif
- File `gradle.properties` harus ada `android.useAndroidX=true`

### "Supabase URL not found"?
- Cek `app/build.gradle.kts` — pastikan `SUPABASE_URL` dan `SUPABASE_KEY` sudah diganti
- Sync project lagi: **File → Sync Project with Gradle Files**

### "google-services.json missing"?
- Download dari Firebase Console (lihat STEP 3)
- Pastikan file ada di `app/google-services.json`

### App crash saat buka?
- Cek **Logcat** di Android Studio (tab Logcat di bawah)
- Pastikan Supabase URL benar (jangan ada spasi atau typo)

---

## 📝 CATATAN PENTING

- **Jangan upload `google-services.json` ke GitHub publik** (berisi API key)
- **Jangan upload `app/build.gradle.kts` dengan Supabase KEY asli** ke publik
- Untuk production, ganti ke **Supabase Pro** dan enable **Certificate Pinning**

---

## 📞 BUTUH BANTUAN?

1. Cek Logcat di Android Studio untuk error detail
2. Pastikan semua 5 STEP di atas sudah dikerjakan
3. Kalau masih error, screenshot Logcat dan kirim

**Selamat coding! 🚀**
