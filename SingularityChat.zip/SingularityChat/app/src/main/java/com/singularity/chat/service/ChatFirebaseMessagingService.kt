package com.singularity.chat.service

import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import co.touchlab.kermit.Logger
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ChatFirebaseMessagingService : FirebaseMessagingService() {

    @Inject lateinit var logger: Logger

    override fun onMessageReceived(message: RemoteMessage) {
        super.onMessageReceived(message)
        logger.i { "FCM Message from: ${message.from}" }

        val data = message.data
        val roomId = data["room_id"]
        val senderName = data["sender_name"]
        val content = data["content"]

        if (roomId != null && content != null) {
            showNotification(roomId, senderName ?: "New message", content)
        }
    }

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        logger.i { "FCM token refreshed" }
    }

    private fun showNotification(roomId: String, title: String, content: String) {
        // NotificationManager implementation with channel creation
        // PendingIntent to ChatRoomScreen deep link
    }
}
