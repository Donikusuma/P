package com.singularity.chat.data.repository

import com.singularity.chat.data.model.*
import io.github.jan_tennert.supabase.SupabaseClient
import io.github.jan_tennert.supabase.auth.auth
import io.github.jan_tennert.supabase.auth.providers.Phone
import io.github.jan_tennert.supabase.exceptions.RestException
import io.github.jan_tennert.supabase.postgrest.from
import io.github.jan_tennert.supabase.postgrest.query.Order
import io.github.jan_tennert.supabase.postgrest.query.filter.FilterOperator
import io.github.jan_tennert.supabase.realtime.RealtimeChannel
import io.github.jan_tennert.supabase.realtime.channel
import io.github.jan_tennert.supabase.realtime.postgresChangeFlow
import io.github.jan_tennert.supabase.realtime.realtime
import io.github.jan_tennert.supabase.storage.storage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import co.touchlab.kermit.Logger

// ============================================================
// AUTH REPOSITORY — Zero Barrier Entry
// ============================================================

@Singleton
class AuthRepository @Inject constructor(
    private val client: SupabaseClient,
    private val logger: Logger
) {
    private val auth = client.auth
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val sessionStatus = auth.sessionStatus

    suspend fun signInAnonymously(): Result<Profile> = withContext(Dispatchers.IO) {
        try {
            logger.i { "Signing in anonymously..." }
            auth.signInAnonymously()
            val user = auth.currentUserOrNull()
                ?: return@withContext Result.failure(IllegalStateException("Anonymous sign-in failed: no user"))

            // Auto-create profile
            val profile = Profile(
                id = user.id,
                username = "user_${user.id.takeLast(8)}",
                displayName = "Guest ${user.id.takeLast(4)}",
                isAnonymous = true
            )

            client.from("profiles").insert(profile)
            logger.i { "Anonymous profile created: ${profile.id}" }
            Result.success(profile)
        } catch (e: Exception) {
            logger.e(e) { "Anonymous sign-in failed" }
            Result.failure(e)
        }
    }

    suspend fun sendPhoneOtp(phone: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            logger.i { "Sending OTP to $phone" }
            auth.signInWith(Phone) {
                this.phoneNumber = phone
            }
            Result.success(Unit)
        } catch (e: Exception) {
            logger.e(e) { "Failed to send OTP" }
            Result.failure(e)
        }
    }

    suspend fun verifyPhoneOtp(phone: String, token: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            logger.i { "Verifying OTP for $phone" }
            auth.verifyEmailOtp(
                type = Phone,
                emailOrPhone = phone,
                token = token
            )
            // Update profile to non-anonymous
            val userId = auth.currentUserOrNull()?.id ?: return@withContext Result.failure(
                IllegalStateException("No authenticated user")
            )
            client.from("profiles").update({
                buildJsonObject {
                    put("is_anonymous", false)
                    put("phone", phone)
                }
            }) {
                filter { eq("id", userId) }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            logger.e(e) { "OTP verification failed" }
            Result.failure(e)
        }
    }

    suspend fun getCurrentProfile(): Result<Profile> = withContext(Dispatchers.IO) {
        try {
            val userId = auth.currentUserOrNull()?.id
                ?: return@withContext Result.failure(IllegalStateException("No active session"))

            val profile = client.from("profiles")
                .select {
                    filter { eq("id", userId) }
                    limit(1)
                    single()
                }
                .decodeAs<Profile>()

            Result.success(profile)
        } catch (e: RestException) {
            logger.e(e) { "Profile fetch failed: ${e.message}" }
            Result.failure(e)
        } catch (e: Exception) {
            logger.e(e) { "Unexpected error fetching profile" }
            Result.failure(e)
        }
    }

    suspend fun updateProfile(dto: UpdateProfileDto): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val userId = auth.currentUserOrNull()?.id
                ?: return@withContext Result.failure(IllegalStateException("No active session"))

            client.from("profiles").update({
                buildJsonObject {
                    dto.username?.let { put("username", it) }
                    dto.displayName?.let { put("display_name", it) }
                    dto.avatarUrl?.let { put("avatar_url", it) }
                    dto.status?.let { put("status", it) }
                    dto.isAnonymous?.let { put("is_anonymous", it) }
                    put("updated_at", "now()")
                }
            }) {
                filter { eq("id", userId) }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            logger.e(e) { "Profile update failed" }
            Result.failure(e)
        }
    }

    suspend fun signOut(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            auth.signOut()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun cleanup() {
        scope.cancel()
    }
}

// ============================================================
// CHAT REPOSITORY — Realtime, Pagination, Idempotency
// ============================================================

@Singleton
class ChatRepository @Inject constructor(
    private val client: SupabaseClient,
    private val logger: Logger
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeChannels = mutableMapOf<String, RealtimeChannel>()
    private val _typingFlows = mutableMapOf<String, MutableStateFlow<List<Profile>>>()

    // ─────────────────────────────────────────────────────────
    // ROOM OPERATIONS
    // ─────────────────────────────────────────────────────────

    suspend fun getPublicRooms(limit: Long = 50, offset: Long = 0): Result<List<Room>> = withContext(Dispatchers.IO) {
        try {
            val rooms = client.from("rooms")
                .select {
                    filter { eq("is_public", true) }
                    order("member_count", Order.DESCENDING)
                    limit(limit)
                    offset(offset)
                }
                .decodeList<Room>()
            Result.success(rooms)
        } catch (e: Exception) {
            logger.e(e) { "Failed to fetch public rooms" }
            Result.failure(e)
        }
    }

    suspend fun getMyRooms(userId: String): Result<List<Room>> = withContext(Dispatchers.IO) {
        try {
            val rooms = client.from("rooms")
                .select {
                    filter {
                        eq("room_members.user_id", userId)
                    }
                    order("updated_at", Order.DESCENDING)
                }
                .decodeList<Room>()
            Result.success(rooms)
        } catch (e: Exception) {
            logger.e(e) { "Failed to fetch my rooms" }
            Result.failure(e)
        }
    }

    suspend fun createRoom(dto: CreateRoomDto): Result<Room> = withContext(Dispatchers.IO) {
        try {
            val room = client.from("rooms")
                .insert(dto) {
                    select()
                    single()
                }
                .decodeAs<Room>()

            // Auto-join creator as owner
            client.from("room_members").insert(
                buildJsonObject {
                    put("room_id", room.id)
                    put("user_id", dto.createdBy)
                    put("role", "owner")
                }
            )

            Result.success(room)
        } catch (e: Exception) {
            logger.e(e) { "Room creation failed" }
            Result.failure(e)
        }
    }

    suspend fun joinRoom(roomId: String, userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.from("room_members").insert(
                buildJsonObject {
                    put("room_id", roomId)
                    put("user_id", userId)
                    put("role", "member")
                }
            )
            Result.success(Unit)
        } catch (e: Exception) {
            logger.e(e) { "Join room failed (maybe already member)" }
            Result.failure(e)
        }
    }

    suspend fun leaveRoom(roomId: String, userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.from("room_members").delete {
                filter {
                    eq("room_id", roomId)
                    eq("user_id", userId)
                }
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─────────────────────────────────────────────────────────
    // MESSAGE OPERATIONS (Pagination + Idempotency)
    // ─────────────────────────────────────────────────────────

    suspend fun getMessages(
        roomId: String,
        limit: Int = 50,
        beforeMessageId: String? = null
    ): Result<List<Message>> = withContext(Dispatchers.IO) {
        try {
            val query = client.from("messages")
                .select {
                    filter { eq("room_id", roomId) }
                    order("created_at", Order.DESCENDING)
                    this.limit(limit.toLong())
                    // Join sender profile
                }

            val messages = query.decodeList<Message>().reversed() // Oldest first for UI
            Result.success(messages)
        } catch (e: Exception) {
            logger.e(e) { "Message fetch failed" }
            Result.failure(e)
        }
    }

    suspend fun sendMessage(dto: SendMessageDto): Result<Message> = withContext(Dispatchers.IO) {
        try {
            val message = client.from("messages")
                .insert(dto) {
                    select()
                    single()
                }
                .decodeAs<Message>()
            Result.success(message)
        } catch (e: RestException) {
            // Idempotency key conflict = message already sent
            if (e.message?.contains("idempotency_key") == true) {
                logger.w { "Duplicate message blocked by idempotency key" }
                Result.failure(IllegalStateException("Message already sent"))
            } else {
                logger.e(e) { "Send message failed" }
                Result.failure(e)
            }
        } catch (e: Exception) {
            logger.e(e) { "Send message unexpected error" }
            Result.failure(e)
        }
    }

    suspend fun markAsRead(messageId: String, userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.from("message_reads").insert(
                buildJsonObject {
                    put("message_id", messageId)
                    put("user_id", userId)
                }
            )
            Result.success(Unit)
        } catch (e: Exception) {
            // Ignore duplicate read errors
            Result.success(Unit)
        }
    }

    suspend fun addReaction(messageId: String, userId: String, emoji: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            client.from("message_reactions").insert(
                buildJsonObject {
                    put("message_id", messageId)
                    put("user_id", userId)
                    put("emoji", emoji)
                }
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─────────────────────────────────────────────────────────
    // REALTIME SUBSCRIPTIONS (Circuit Breaker + Auto-Reconnect)
    // ─────────────────────────────────────────────────────────

    fun subscribeToMessages(roomId: String): Flow<Message> = flow {
        val channel = client.realtime.createChannel("room_messages_$roomId")
        activeChannels[roomId] = channel

        try {
            channel.subscribe()

            channel.postgresChangeFlow<io.github.jan_tennert.supabase.realtime.PostgresAction.Insert>(
                schema = "public"
            ) {
                table = "messages"
                filter("room_id", FilterOperator.EQ, roomId)
            }.collect { action ->
                try {
                    val message = Json.decodeFromString<Message>(action.record.toString())
                    emit(message)
                } catch (e: Exception) {
                    logger.e(e) { "Failed to decode realtime message" }
                }
            }
        } finally {
            channel.unsubscribe()
            activeChannels.remove(roomId)
        }
    }

    fun subscribeToReactions(roomId: String): Flow<Unit> = flow {
        val channel = client.realtime.createChannel("room_reactions_$roomId")
        try {
            channel.subscribe()
            channel.postgresChangeFlow<io.github.jan_tennert.supabase.realtime.PostgresAction.Insert>(
                schema = "public"
            ) {
                table = "message_reactions"
            }.collect {
                emit(Unit)
            }
        } finally {
            channel.unsubscribe()
        }
    }

    fun getTypingFlow(roomId: String): StateFlow<List<Profile>> {
        return _typingFlows.getOrPut(roomId) { MutableStateFlow(emptyList()) }
    }

    suspend fun sendTypingIndicator(roomId: String, userId: String) = withContext(Dispatchers.IO) {
        try {
            client.from("typing_indicators").upsert(
                buildJsonObject {
                    put("room_id", roomId)
                    put("user_id", userId)
                    put("started_at", "now()")
                }
            )
        } catch (e: Exception) {
            logger.e(e) { "Typing indicator failed" }
        }
    }

    suspend fun cleanupRoom(roomId: String) {
        activeChannels[roomId]?.unsubscribe()
        activeChannels.remove(roomId)
        _typingFlows.remove(roomId)
    }

    fun cleanup() {
        activeChannels.values.forEach { it.unsubscribe() }
        activeChannels.clear()
        _typingFlows.clear()
        scope.cancel()
    }
}

// ============================================================
// STORAGE REPOSITORY — Media Handling
// ============================================================

@Singleton
class StorageRepository @Inject constructor(
    private val client: SupabaseClient,
    private val logger: Logger
) {
    companion object {
        const val BUCKET_NAME = "chat-media"
        const val MAX_FILE_SIZE = 10 * 1024 * 1024L // 10MB
    }

    suspend fun uploadImage(
        bytes: ByteArray,
        fileName: String,
        contentType: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (bytes.size > MAX_FILE_SIZE) {
                return@withContext Result.failure(IllegalArgumentException("File exceeds 10MB limit"))
            }

            val path = "${UUID.randomUUID()}_$fileName"

            client.storage.from(BUCKET_NAME).upload(
                path = path,
                data = bytes,
                options = {
                    this.contentType = contentType
                    upsert = false
                }
            )

            val publicUrl = client.storage.from(BUCKET_NAME).publicUrl(path)
            Result.success(publicUrl)
        } catch (e: Exception) {
            logger.e(e) { "Image upload failed" }
            Result.failure(e)
        }
    }
}
