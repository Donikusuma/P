package com.singularity.chat.di

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.singularity.chat.BuildConfig
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import io.github.jan_tennert.supabase.SupabaseClient
import io.github.jan_tennert.supabase.createSupabaseClient
import io.github.jan_tennert.supabase.auth.Auth
import io.github.jan_tennert.supabase.postgrest.Postgrest
import io.github.jan_tennert.supabase.realtime.Realtime
import io.github.jan_tennert.supabase.storage.Storage
import io.ktor.client.HttpClient
import io.ktor.client.engine.okhttp.OkHttp
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logging
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json
import okhttp3.CertificatePinner
import okhttp3.ConnectionSpec
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import javax.inject.Singleton
import co.touchlab.kermit.Logger
import co.touchlab.kermit.StaticConfig
import co.touchlab.kermit.platformLogWriter

@Module
@InstallIn(SingletonComponent::class)
object SupabaseModule {

    @Provides
    @Singleton
    fun provideJson(): Json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = false
        explicitNulls = false
        encodeDefaults = true
        isLenient = false
    }

    @Provides
    @Singleton
    fun provideMasterKey(@ApplicationContext context: Context): MasterKey {
        return MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    @Provides
    @Singleton
    fun provideEncryptedPrefs(
        @ApplicationContext context: Context,
        masterKey: MasterKey
    ): EncryptedSharedPreferences {
        return EncryptedSharedPreferences.create(
            context,
            "chat_secure_prefs",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        ) as EncryptedSharedPreferences
    }

    @Provides
    @Singleton
    fun provideKtorClient(json: Json): HttpClient {
        val certificatePinner = if (BuildConfig.BUILD_TYPE == "release") {
            CertificatePinner.Builder()
                .add(BuildConfig.SUPABASE_HOST, "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=") // TODO: Replace with actual SPKI hash
                .build()
        } else null

        val okHttpClient = OkHttpClient.Builder().apply {
            connectTimeout(15, TimeUnit.SECONDS)
            readTimeout(30, TimeUnit.SECONDS)
            writeTimeout(30, TimeUnit.SECONDS)
            retryOnConnectionFailure(true)
            connectionSpecs(listOf(ConnectionSpec.MODERN_TLS))
            certificatePinner?.let { certificatePinner(it) }
            addInterceptor { chain ->
                val request = chain.request().newBuilder()
                    .header("X-Client-Info", "android-chat/1.0.0")
                    .build()
                chain.proceed(request)
            }
        }.build()

        return HttpClient(OkHttp) {
            engine { preconfigured = okHttpClient }
            install(HttpTimeout) {
                requestTimeoutMillis = 30000
                connectTimeoutMillis = 15000
                socketTimeoutMillis = 30000
            }
            install(ContentNegotiation) { json(json) }
            install(Logging) {
                level = if (BuildConfig.DEBUG) LogLevel.ALL else LogLevel.NONE
            }
        }
    }

    @Provides
    @Singleton
    fun provideSupabaseClient(
        json: Json,
        httpClient: HttpClient
    ): SupabaseClient {
        return createSupabaseClient(
            supabaseUrl = BuildConfig.SUPABASE_URL,
            supabaseKey = BuildConfig.SUPABASE_KEY
        ) {
            this.httpClient = httpClient
            defaultSerializer = json

            install(Auth) {
                // Session auto-refresh enabled by default
                // Flow settings
            }
            install(Postgrest) {
                // Default schema
            }
            install(Realtime) {
                reconnectDelay = 1000L
                heartbeatInterval = 30000L
            }
            install(Storage) {
                // Transfer timeout handled by Ktor
            }
        }
    }

    @Provides
    @Singleton
    fun provideLogger(): Logger = Logger(
        config = StaticConfig(logWriterList = listOf(platformLogWriter())),
        tag = "SingularityChat"
    )
}
