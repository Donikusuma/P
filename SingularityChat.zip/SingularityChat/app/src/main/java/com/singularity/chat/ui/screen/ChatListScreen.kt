package com.singularity.chat.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.singularity.chat.data.model.Room
import com.singularity.chat.data.model.UiState
import com.singularity.chat.ui.viewmodel.ChatListViewModel
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
    onNavigateToRoom: (String, String) -> Unit,
    onNavigateToCreateRoom: () -> Unit,
    onNavigateToProfile: () -> Unit,
    viewModel: ChatListViewModel = hiltViewModel()
) {
    val publicRoomsState by viewModel.publicRooms.collectAsState()
    val myRoomsState by viewModel.myRooms.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var searchQuery by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Messages") },
                actions = {
                    IconButton(onClick = onNavigateToProfile) {
                        Icon(Icons.Default.Person, contentDescription = "Profile")
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNavigateToCreateRoom) {
                Icon(Icons.Default.Add, contentDescription = "Create Room")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Search bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                placeholder = { Text("Search rooms...") },
                leadingIcon = { Icon(Icons.Default.Search, null) },
                singleLine = true
            )

            // Tabs
            TabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("My Chats") }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Discover") }
                )
            }

            when (selectedTab) {
                0 -> RoomList(
                    state = myRoomsState,
                    searchQuery = searchQuery,
                    onRoomClick = onNavigateToRoom,
                    emptyText = "No chats yet. Join a room or create one!"
                )
                1 -> RoomList(
                    state = publicRoomsState,
                    searchQuery = searchQuery,
                    onRoomClick = { roomId, roomName ->
                        viewModel.joinRoom(roomId)
                        onNavigateToRoom(roomId, roomName)
                    },
                    emptyText = "No public rooms available",
                    showMemberCount = true
                )
            }
        }
    }
}

@Composable
private fun RoomList(
    state: UiState<List<Room>>,
    searchQuery: String,
    onRoomClick: (String, String) -> Unit,
    emptyText: String,
    showMemberCount: Boolean = false
) {
    when (state) {
        is UiState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        is UiState.Error -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(state.message, color = MaterialTheme.colorScheme.error)
            }
        }
        is UiState.Success -> {
            val filtered = state.data.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                it.description.contains(searchQuery, ignoreCase = true)
            }

            if (filtered.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(emptyText, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn {
                    items(filtered, key = { it.id }) { room ->
                        RoomItem(
                            room = room,
                            onClick = { onRoomClick(room.id, room.name) },
                            showMemberCount = showMemberCount
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}

@Composable
private fun RoomItem(
    room: Room,
    onClick: () -> Unit,
    showMemberCount: Boolean
) {
    ListItem(
        headlineContent = {
            Text(
                text = room.name,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        },
        supportingContent = {
            Text(
                text = room.description.ifBlank { "${room.member_count} members · ${room.message_count} messages" },
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall
            )
        },
        trailingContent = if (showMemberCount) {
            { Badge { Text("${room.member_count}") } }
        } else null,
        modifier = Modifier.clickable { onClick() }
    )
}
