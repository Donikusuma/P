package com.singularity.chat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.singularity.chat.ui.navigation.Screen
import com.singularity.chat.ui.screen.AuthScreen
import com.singularity.chat.ui.screen.ChatListScreen
import com.singularity.chat.ui.screen.ChatRoomScreen
import com.singularity.chat.ui.screen.CreateRoomScreen
import com.singularity.chat.ui.screen.ProfileScreen
import com.singularity.chat.ui.theme.SingularityChatTheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SingularityChatTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val navController = rememberNavController()

                    NavHost(navController = navController, startDestination = Screen.Auth) {
                        composable<Screen.Auth> {
                            AuthScreen(
                                onNavigateToChatList = {
                                    navController.navigate(Screen.ChatList) {
                                        popUpTo(Screen.Auth) { inclusive = true }
                                    }
                                }
                            )
                        }
                        composable<Screen.ChatList> {
                            ChatListScreen(
                                onNavigateToRoom = { roomId, roomName ->
                                    navController.navigate(Screen.ChatRoom(roomId, roomName))
                                },
                                onNavigateToCreateRoom = {
                                    navController.navigate(Screen.CreateRoom)
                                },
                                onNavigateToProfile = {
                                    navController.navigate(Screen.Profile)
                                }
                            )
                        }
                        composable<Screen.ChatRoom> { backStackEntry ->
                            val route = backStackEntry.toRoute<Screen.ChatRoom>()
                            ChatRoomScreen(
                                roomId = route.roomId,
                                roomName = route.roomName,
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                        composable<Screen.CreateRoom> {
                            CreateRoomScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                        composable<Screen.Profile> {
                            ProfileScreen(
                                onNavigateBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }
}
