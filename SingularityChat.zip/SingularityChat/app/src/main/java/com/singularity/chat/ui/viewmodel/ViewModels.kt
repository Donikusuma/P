package com.singularity.chat.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.singularity.chat.data.model.*
import com.singularity.chat.data.repository.AuthRepository
import com.singularity.chat.data.repository.ChatRepository
import com.singularity.chat.data.repository.StorageRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID
import javax.inject.Inject

// ============================================================
// AUTH VIEWMODEL — Zero Barrier Entry
// ============================================================

@HiltViewModel
class AuthViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<Profile>>(UiState.Loading)
    val uiState: StateFlow<UiState<Profile>> = _uiState.asStateFlow()

    private val _isAuthenticated = MutableStateFlow(false)
    val isAuthenticated: StateFlow<Boolean> = _isAuthenticated.asStateFlow()

    init {
        // Check existing session on startup
        viewModelScope.launch {
            authRepository.sessionStatus.collect { status ->
                when (status) {
                    is io.github.jan_tennert.supabase.auth.SessionStatus.Authenticated -> {
                        _isAuthenticated.value = true
                        fetchProfile()
                    }
                    is io.github.jan_tennert.supabase.auth.SessionStatus.NotAuthenticated -> {
                        _isAuthenticated.value = false
                        _uiState.value = UiState.Error("Not authenticated", "AUTH_REQUIRED")
                    }
                    else -> { /* Loading */ }
                }
            }
        }
    }

    fun signInAnonymously() {
        _uiState.value = UiState.Loading
        viewModelScope.launch {
            authRepository.signInAnonymously()
                .onSuccess { profile ->
                    _uiState.value = UiState.Success(profile)
                    _isAuthenticated.value = true
                }
                .onFailure { error ->
                    _uiState.value = UiState.Error(error.message ?: "Unknown error", "ANON_FAILED")
                }
        }
    }

    private fun fetchProfile() {
        viewModelScope.launch {
            authRepository.getCurrentProfile()
                .onSuccess { profile ->
                    _uiState.value = UiState.Success(profile)
                }
                .onFailure { error ->
                    _uiState.value = UiState.Error(error.message ?: "Profile load failed", "PROFILE_FAILED")
                }
        }
    }

    fun signOut() {
        viewModelScope.launch {
            authRepository.signOut()
            _isAuthenticated.value = false
            _uiState.value = UiState.Error("Signed out", "SIGNED_OUT")
        }
    }
}

// ============================================================
// CHAT LIST VIEWMODEL — Room Discovery & Management
// ============================================================

@HiltViewModel
class ChatListViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _publicRooms = MutableStateFlow<UiState<List<Room>>>(UiState.Loading)
    val publicRooms: StateFlow<UiState<List<Room>>> = _publicRooms.asStateFlow()

    private val _myRooms = MutableStateFlow<UiState<List<Room>>>(UiState.Loading)
    val myRooms: StateFlow<UiState<List<Room>>> = _myRooms.asStateFlow()

    private val _joinState = MutableStateFlow<UiState<Unit>>(UiState.Success(Unit))
    val joinState: StateFlow<UiState<Unit>> = _joinState.asStateFlow()

    private val _createState = MutableStateFlow<UiState<Room>>(UiState.Success(Unit) as UiState<Room>)
    val createState: StateFlow<UiState<Room>> = _createState.asStateFlow()

    init {
        loadPublicRooms()
        loadMyRooms()
    }

    fun loadPublicRooms() {
        _publicRooms.value = UiState.Loading
        viewModelScope.launch {
            chatRepository.getPublicRooms()
                .onSuccess { rooms ->
                    _publicRooms.value = UiState.Success(rooms)
                }
                .onFailure { error ->
                    _publicRooms.value = UiState.Error(error.message ?: "Failed to load rooms", "ROOMS_FETCH_FAILED")
                }
        }
    }

    fun loadMyRooms() {
        _myRooms.value = UiState.Loading
        viewModelScope.launch {
            val userId = authRepository.sessionStatus.value.let {
                if (it is io.github.jan_tennert.supabase.auth.SessionStatus.Authenticated) it.session.user?.id else null
            } ?: return@launch

            chatRepository.getMyRooms(userId)
                .onSuccess { rooms ->
                    _myRooms.value = UiState.Success(rooms)
                }
                .onFailure { error ->
                    _myRooms.value = UiState.Error(error.message ?: "Failed to load chats", "MY_ROOMS_FAILED")
                }
        }
    }

    fun joinRoom(roomId: String) {
        _joinState.value = UiState.Loading
        viewModelScope.launch {
            val userId = authRepository.sessionStatus.value.let {
                if (it is io.github.jan_tennert.supabase.auth.SessionStatus.Authenticated) it.session.user?.id else null
            } ?: return@launch

            chatRepository.joinRoom(roomId, userId)
                .onSuccess {
                    _joinState.value = UiState.Success(Unit)
                    loadMyRooms() // Refresh
                }
                .onFailure { error ->
                    _joinState.value = UiState.Error(error.message ?: "Join failed", "JOIN_FAILED")
                }
        }
    }

    fun createRoom(name: String, description: String, isPublic: Boolean = true) {
        _createState.value = UiState.Loading
        viewModelScope.launch {
            val userId = authRepository.sessionStatus.value.let {
                if (it is io.github.jan_tennert.supabase.auth.SessionStatus.Authenticated) it.session.user?.id else null
            } ?: return@launch

            val dto = CreateRoomDto(
                name = name,
                description = description,
                isPublic = isPublic,
                createdBy = userId
            )

            chatRepository.createRoom(dto)
                .onSuccess { room ->
                    _createState.value = UiState.Success(room)
                    loadMyRooms()
                    loadPublicRooms()
                }
                .onFailure { error ->
                    _createState.value = UiState.Error(error.message ?: "Create failed", "CREATE_FAILED")
                }
        }
    }
}

// ============================================================
// CHAT ROOM VIEWMODEL — Realtime Messaging Engine
// ============================================================

@HiltViewModel
class ChatRoomViewModel @Inject constructor(
    private val chatRepository: ChatRepository,
    private val authRepository: AuthRepository,
    private val storageRepository: StorageRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(ChatRoomUiState())
    val uiState: StateFlow<ChatRoomUiState> = _uiState.asStateFlow()

    private val _currentUserId = MutableStateFlow<String?>(null)

    private var realtimeJob: Job? = null
    private var typingJob: Job? = null
    private var loadJob: Job? = null

    init {
        viewModelScope.launch {
            authRepository.sessionStatus.collect { status ->
                if (status is io.github.jan_tennert.supabase.auth.SessionStatus.Authenticated) {
                    _currentUserId.value = status.session.user?.id
                }
            }
        }
    }

    fun loadRoom(roomId: String) {
        loadJob?.cancel()
        _uiState.update { it.copy(isLoadingMore = true) }

        loadJob = viewModelScope.launch {
            chatRepository.getMessages(roomId, limit = 50)
                .onSuccess { messages ->
                    _uiState.update {
                        it.copy(
                            messages = messages,
                            hasMoreMessages = messages.size >= 50,
                            isLoadingMore = false
                        )
                    }
                    subscribeToRealtime(roomId)
                }
                .onFailure { error ->
                    _uiState.update { it.copy(isLoadingMore = false) }
                }
        }
    }

    fun loadMoreMessages(roomId: String) {
        if (_uiState.value.isLoadingMore || !_uiState.value.hasMoreMessages) return

        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingMore = true) }
            val oldestMessage = _uiState.value.messages.firstOrNull()

            chatRepository.getMessages(roomId, limit = 50, beforeMessageId = oldestMessage?.id)
                .onSuccess { olderMessages ->
                    _uiState.update { current ->
                        current.copy(
                            messages = olderMessages + current.messages,
                            hasMoreMessages = olderMessages.size >= 50,
                            isLoadingMore = false
                        )
                    }
                }
                .onFailure {
                    _uiState.update { it.copy(isLoadingMore = false) }
                }
        }
    }

    private fun subscribeToRealtime(roomId: String) {
        realtimeJob?.cancel()

        realtimeJob = viewModelScope.launch {
            chatRepository.subscribeToMessages(roomId)
                .catch { /* Handle stream error */ }
                .onEach { newMessage ->
                    _uiState.update { current ->
                        // Prevent duplicates
                        if (current.messages.any { it.id == newMessage.id }) return@onEach
                        current.copy(
                            messages = current.messages + newMessage,
                            sendState = if (newMessage.senderId == _currentUserId.value) SendState.Sent(newMessage.id) else current.sendState
                        )
                    }
                    // Auto-mark as read
                    _currentUserId.value?.let { userId ->
                        chatRepository.markAsRead(newMessage.id, userId)
                    }
                }
                .launchIn(viewModelScope)
        }
    }

    fun sendMessage(roomId: String, content: String, replyToId: String? = null) {
        val userId = _currentUserId.value ?: return
        if (content.isBlank()) return

        _uiState.update { it.copy(sendState = SendState.Sending) }

        viewModelScope.launch {
            val dto = SendMessageDto(
                roomId = roomId,
                senderId = userId,
                content = content.trim(),
                replyToMessageId = replyToId,
                idempotencyKey = UUID.randomUUID().toString()
            )

            chatRepository.sendMessage(dto)
                .onSuccess { message ->
                    _uiState.update {
                        it.copy(
                            messages = it.messages + message,
                            sendState = SendState.Sent(message.id)
                        )
                    }
                }
                .onFailure { error ->
                    _uiState.update {
                        it.copy(sendState = SendState.Failed(error.message ?: "Send failed"))
                    }
                }
        }
    }

    fun sendImage(roomId: String, imageBytes: ByteArray, fileName: String) {
        val userId = _currentUserId.value ?: return

        viewModelScope.launch {
            _uiState.update { it.copy(sendState = SendState.Sending) }

            storageRepository.uploadImage(imageBytes, fileName, "image/jpeg")
                .onSuccess { imageUrl ->
                    val dto = SendMessageDto(
                        roomId = roomId,
                        senderId = userId,
                        content = imageUrl,
                        contentType = "image",
                        idempotencyKey = UUID.randomUUID().toString(),
                        metadata = mapOf("file_name" to fileName)
                    )
                    chatRepository.sendMessage(dto)
                }
                .onFailure { error ->
                    _uiState.update { it.copy(sendState = SendState.Failed(error.message ?: "Upload failed")) }
                }
        }
    }

    fun addReaction(messageId: String, emoji: String) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            chatRepository.addReaction(messageId, userId, emoji)
        }
    }

    fun sendTyping(roomId: String) {
        val userId = _currentUserId.value ?: return
        typingJob?.cancel()
        typingJob = viewModelScope.launch {
            chatRepository.sendTypingIndicator(roomId, userId)
            delay(3000) // Debounce: only send every 3 seconds max
        }
    }

    fun leaveRoom(roomId: String) {
        val userId = _currentUserId.value ?: return
        viewModelScope.launch {
            chatRepository.leaveRoom(roomId, userId)
            cleanup()
        }
    }

    fun cleanup() {
        realtimeJob?.cancel()
        typingJob?.cancel()
        loadJob?.cancel()
    }

    override fun onCleared() {
        super.onCleared()
        cleanup()
    }
}

// ============================================================
// PROFILE VIEWMODEL
// ============================================================

@HiltViewModel
class ProfileViewModel @Inject constructor(
    private val authRepository: AuthRepository
) : ViewModel() {

    private val _profile = MutableStateFlow<UiState<Profile>>(UiState.Loading)
    val profile: StateFlow<UiState<Profile>> = _profile.asStateFlow()

    private val _updateState = MutableStateFlow<UiState<Unit>>(UiState.Success(Unit))
    val updateState: StateFlow<UiState<Unit>> = _updateState.asStateFlow()

    init {
        loadProfile()
    }

    fun loadProfile() {
        _profile.value = UiState.Loading
        viewModelScope.launch {
            authRepository.getCurrentProfile()
                .onSuccess { profile ->
                    _profile.value = UiState.Success(profile)
                }
                .onFailure { error ->
                    _profile.value = UiState.Error(error.message ?: "Failed to load profile", "PROFILE_LOAD_FAILED")
                }
        }
    }

    fun updateProfile(username: String?, displayName: String?, status: String?) {
        _updateState.value = UiState.Loading
        viewModelScope.launch {
            val dto = UpdateProfileDto(
                username = username,
                displayName = displayName,
                status = status
            )
            authRepository.updateProfile(dto)
                .onSuccess {
                    _updateState.value = UiState.Success(Unit)
                    loadProfile()
                }
                .onFailure { error ->
                    _updateState.value = UiState.Error(error.message ?: "Update failed", "UPDATE_FAILED")
                }
        }
    }
}
