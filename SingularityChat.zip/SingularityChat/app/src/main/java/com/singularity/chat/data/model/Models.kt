package com.singularity.chat.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.datetime.Instant

// ============================================================
// CORE DOMAIN MODELS — Immutable, Serializable, Strict
// ============================================================

@Serializable
data class Profile(
    @SerialName("id") val id: String,
    @SerialName("username") val username: String,
    @SerialName("display_name") val displayName: String,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("phone") val phone: String? = null,
    @SerialName("is_anonymous") val isAnonymous: Boolean = true,
    @SerialName("status") val status: String = "online",
    @SerialName("last_seen_at") val lastSeenAt: Instant? = null,
    @SerialName("created_at") val createdAt: Instant? = null
)

@Serializable
data class Room(
    @SerialName("id") val id: String,
    @SerialName("name") val name: String,
    @SerialName("description") val description: String = "",
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("created_by") val createdBy: String,
    @SerialName("is_public") val isPublic: Boolean = true,
    @SerialName("is_direct_message") val isDirectMessage: Boolean = false,
    @SerialName("max_members") val maxMembers: Int = 1000,
    @SerialName("member_count") val memberCount: Int = 0,
    @SerialName("message_count") val messageCount: Int = 0,
    @SerialName("created_at") val createdAt: Instant? = null,
    @SerialName("updated_at") val updatedAt: Instant? = null
)

@Serializable
data class RoomMember(
    @SerialName("id") val id: String,
    @SerialName("room_id") val roomId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("role") val role: String = "member",
    @SerialName("joined_at") val joinedAt: Instant? = null,
    @SerialName("last_read_message_id") val lastReadMessageId: String? = null,
    @SerialName("is_muted") val isMuted: Boolean = false
)

@Serializable
data class Message(
    @SerialName("id") val id: String,
    @SerialName("room_id") val roomId: String,
    @SerialName("sender_id") val senderId: String,
    @SerialName("content") val content: String,
    @SerialName("content_type") val contentType: String = "text",
    @SerialName("reply_to_message_id") val replyToMessageId: String? = null,
    @SerialName("metadata") val metadata: Map<String, String?> = emptyMap(),
    @SerialName("is_edited") val isEdited: Boolean = false,
    @SerialName("edited_at") val editedAt: Instant? = null,
    @SerialName("idempotency_key") val idempotencyKey: String? = null,
    @SerialName("created_at") val createdAt: Instant? = null,
    // Joined fields (not in DB, populated by query)
    @SerialName("sender") val sender: Profile? = null,
    @SerialName("read_count") val readCount: Long? = null,
    @SerialName("reactions") val reactions: List<MessageReaction>? = null
)

@Serializable
data class MessageReaction(
    @SerialName("id") val id: String,
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("emoji") val emoji: String,
    @SerialName("created_at") val createdAt: Instant? = null
)

@Serializable
data class MessageRead(
    @SerialName("id") val id: String,
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("read_at") val readAt: Instant? = null
)

@Serializable
data class Attachment(
    @SerialName("id") val id: String,
    @SerialName("message_id") val messageId: String? = null,
    @SerialName("file_name") val fileName: String,
    @SerialName("file_type") val fileType: String,
    @SerialName("file_size") val fileSize: Int,
    @SerialName("storage_path") val storagePath: String,
    @SerialName("public_url") val publicUrl: String? = null,
    @SerialName("created_at") val createdAt: Instant? = null
)

@Serializable
data class TypingIndicator(
    @SerialName("room_id") val roomId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("started_at") val startedAt: Instant? = null,
    // Joined
    @SerialName("user") val user: Profile? = null
)

// ============================================================
// DTOs for Insert/Update (strict boundary, no extra fields)
// ============================================================

@Serializable
data class CreateRoomDto(
    @SerialName("name") val name: String,
    @SerialName("description") val description: String = "",
    @SerialName("is_public") val isPublic: Boolean = true,
    @SerialName("created_by") val createdBy: String
)

@Serializable
data class SendMessageDto(
    @SerialName("room_id") val roomId: String,
    @SerialName("sender_id") val senderId: String,
    @SerialName("content") val content: String,
    @SerialName("content_type") val contentType: String = "text",
    @SerialName("reply_to_message_id") val replyToMessageId: String? = null,
    @SerialName("idempotency_key") val idempotencyKey: String,
    @SerialName("metadata") val metadata: Map<String, String?> = emptyMap()
)

@Serializable
data class CreateReactionDto(
    @SerialName("message_id") val messageId: String,
    @SerialName("user_id") val userId: String,
    @SerialName("emoji") val emoji: String
)

@Serializable
data class UpdateProfileDto(
    @SerialName("username") val username: String? = null,
    @SerialName("display_name") val displayName: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("status") val status: String? = null,
    @SerialName("is_anonymous") val isAnonymous: Boolean? = null
)

// ============================================================
// UI State Models (sealed classes for unidirectional data flow)
// ============================================================

sealed class UiState<out T> {
    data object Loading : UiState<Nothing>()
    data class Success<T>(val data: T) : UiState<T>()
    data class Error(val message: String, val code: String? = null) : UiState<Nothing>()
}

data class ChatRoomUiState(
    val room: Room? = null,
    val messages: List<Message> = emptyList(),
    val typingUsers: List<Profile> = emptyList(),
    val hasMoreMessages: Boolean = true,
    val isLoadingMore: Boolean = false,
    val sendState: SendState = SendState.Idle
)

sealed class SendState {
    data object Idle : SendState()
    data object Sending : SendState()
    data class Sent(val messageId: String) : SendState()
    data class Failed(val error: String) : SendState()
}
