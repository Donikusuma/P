package com.singularity.chat.ui.navigation

import kotlinx.serialization.Serializable

sealed class Screen {
    @Serializable data object Auth : Screen()
    @Serializable data object ChatList : Screen()
    @Serializable data class ChatRoom(val roomId: String, val roomName: String) : Screen()
    @Serializable data object CreateRoom : Screen()
    @Serializable data object Profile : Screen()
}
