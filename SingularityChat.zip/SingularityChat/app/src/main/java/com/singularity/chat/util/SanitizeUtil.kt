package com.singularity.chat.util

object SanitizeUtil {
    private const val MAX_MESSAGE_LENGTH = 4096
    private const val MAX_USERNAME_LENGTH = 30
    private const val MAX_DISPLAY_NAME_LENGTH = 50

    fun sanitizeMessage(input: String): String {
        return input
            .trim()
            .take(MAX_MESSAGE_LENGTH)
            .replace(Regex("[\x00-\x08\x0b\x0c\x0e-\x1f]"), "")
            .replace(Regex("<script.*?>.*?</script>", RegexOption.IGNORE_CASE), "")
            .replace(Regex("<[^>]*>"), "")
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace(""", "&quot;")
            .replace("'", "&#x27;")
    }

    fun sanitizeUsername(input: String): String {
        return input
            .trim()
            .lowercase()
            .take(MAX_USERNAME_LENGTH)
            .replace(Regex("[^a-z0-9_]"), "")
    }

    fun sanitizeDisplayName(input: String): String {
        return input
            .trim()
            .take(MAX_DISPLAY_NAME_LENGTH)
            .replace(Regex("[\x00-\x1f]"), "")
    }

    fun isValidMessage(input: String): Boolean {
        return input.isNotBlank() && input.length <= MAX_MESSAGE_LENGTH
    }
}
