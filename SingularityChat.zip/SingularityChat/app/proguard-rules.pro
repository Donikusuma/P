# ProGuard rules for Singularity Chat
-keep class io.github.jan_tennert.supabase.** { *; }
-keep class io.ktor.** { *; }
-keep class kotlinx.serialization.** { *; }
-keep class coil3.** { *; }
-dontwarn coil3.**
-keep class androidx.security.** { *; }
-keep class com.google.firebase.** { *; }
-dontwarn com.google.firebase.**
-keep class kotlinx.datetime.** { *; }
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager { *; }
-keepclassmembers class com.singularity.chat.data.model.** {
    <fields>;
    <init>(...);
}
